USE sintegra;

-- cria o usu�rio associado ao login acima
CREATE USER sintegra FOR LOGIN sintegra;

-- permiss�o total (leitura e escrita) nesse banco
ALTER ROLE db_owner ADD MEMBER sintegra;