CREATE TABLE Eventos_criticos (
    id INT IDENTITY(1,1) PRIMARY KEY,
    Horario DATETIME DEFAULT CURRENT_TIMESTAMP,
    sensor VARCHAR(50),
    Temperatura_critica DECIMAL(5,2),
    Mensagem VARCHAR(100) DEFAULT 'ALERTA: Superaquecimento detectado!'
);
